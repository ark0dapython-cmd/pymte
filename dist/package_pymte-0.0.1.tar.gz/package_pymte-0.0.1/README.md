[project]
name = "package_pymte"
version = "0.0.1"
authors = [
  { name="Ark0da_", email="ark0da.python@gmail.com" },
]
description = "Module destiné au BTS MTE (Moteurs Toutes Énergies)"
readme = "README.md"
requires-python = ">=3.14"
classifiers = [
    "Programming Language :: Python :: 3",
    "Operating System :: OS Independent",
]
license = "MIT"
license-files = ["LICEN[CS]E*"]